package com.example.difzachet_b1

import android.app.VoiceInteractor.Request
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.design.widget.Snackbar
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.android.volley.RequestQueue
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import org.json.JSONObject

class WeatherActivity : AppCompatActivity() {
    private val apiKey = "c357ddaeb7424a07b3042319231011"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_weather)
        val showButton = findViewById<Button>(R.id.buttonshow)
        val perhod=findViewById<Button>(R.id.infobut)
        val cityNameEditText = findViewById<EditText>(R.id.editText)
        perhod.setOnClickListener{
            val intent=Intent(this, InfoActivity::class.java)
            startActivity(intent)
        }
        showButton.setOnClickListener {
            val cityName = cityNameEditText.text.toString()
            weater(cityName)
        }
    }
    private fun weater(city:String){
        if (city.isNotEmpty()) {
            val url = "https://api.weatherapi.com/v1/current.json?key=${apiKey}&q=${city}&api=no"

            val queue: RequestQueue = Volley.newRequestQueue(this)
            val stringRequest = StringRequest(
                com.android.volley.Request.Method.GET, url,
                { response ->
                    try {
                        val obj = JSONObject(response)
                        val temp = obj.getJSONObject("current").getInt("temp_c")
                        val pressure = obj.getJSONObject("current").getString("pressure_mb")
                        val windSpeed = obj.getJSONObject("current").getString("wind_mph")
                        val name=obj.getJSONObject("location").getString("name")
                        val humidity=obj.getJSONObject("current").getString("humidity")
                        val data=obj.getJSONObject("location").getString("localtime")

                        val info = findViewById<TextView>(R.id.text)

                       info.text="Город: $name\nДата: $data \nТемпература: $temp℃ \nДавление: $pressure в миллибарах\nСкорость ветра:$windSpeed м/ч\nВлажность:$humidity % "
                        val sharedPreferences=getSharedPreferences("fact", MODE_PRIVATE)
                        val editor:SharedPreferences.Editor=sharedPreferences.edit()
                        editor.putString("facts",info.text.toString())
                        editor.apply()

                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                },
                { error ->
                    Toast.makeText(this,"Error:$error",Toast.LENGTH_SHORT)
                })

            queue.add(stringRequest)
        } else {
            val sn = Snackbar.make(
                findViewById(android.R.id.content),
                R.string.error,
                Snackbar.LENGTH_LONG
            )
            sn.setActionTextColor(Color.RED)
            sn.show()
        }
    }
}